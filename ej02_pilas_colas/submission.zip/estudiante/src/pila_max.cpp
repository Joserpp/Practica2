#include <iostream>
#include "maxstack.h"
#include "maxqueue.h"
using namespace std;

int main(int argc, char *argv[]){

    // // Run the current exercise
     MaxPila stack;

     for(int i = 1; i < argc; i++){
         if (argv[i][0] == '.'){
             cout << stack.top() << endl;
             stack.pop();
         } else {
             stack.push(atoi(argv[i]));
         }
     }
    return 0;
}
